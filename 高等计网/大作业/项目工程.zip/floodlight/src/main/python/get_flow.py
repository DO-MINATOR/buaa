import csv
from operator import attrgetter
from thrift import Thrift
from thrift.transport import TSocket
from thrift.transport import TTransport
import json

class MyMonitor13(simple_switch_13.SimpleSwitch13):
    def __init__(self,*args,**kwargs):
        super(MyMonitor13,self).__init__(*args,**kwargs)
        self.datapaths={}
        self.monitor_thread=hub.spawn(self._monitor)


    # 获取datapath信息
    @set_ev_cls(ofp_event.EventOFPStateChange,[MAIN_DISPATCHER,DEAD_DISPATCHER])
    def _state_change_handler(self,ev):
        datapath=ev.datapath
        if ev.state == MAIN_DISPATCHER:
            if  datapath.id not in self.datapaths:
                self.datapaths[datapath.id]=datapath
                self.logger.debug("register datapath :%16x",datapath.id)
        elif ev.state==DEAD_DISPATCHER:
            if datapath.id in self.datapaths:
                del self.datapaths[datapath.id]
                self.logger.debug("unregister datapath :%16x",datapath.id)


    # 周期向交换机发送请求
    def _monitor(self):
        while True:
            for dp in self.datapaths.values():
                self._request_stats(dp)
            hub.sleep(1)#每1秒钟向交换机请求一次

    #向交换机发送轻请求
    def _request_stats(self,datapath):
        ofproto = datapath.ofproto
        ofp_parser=datapath.ofproto_parser
        #发送请求
        # req=ofp_parser.OFPPortStatsRequest(datapath,0,ofproto.OFPP_ANY)
        # datapath.send_msg(req)#对端口信息的请求
        req = ofp_parser.OFPFlowStatsRequest(datapath)
        datapath.send_msg(req)#对流表信息的请求
        self.logger.debug("send stats request to datapath : %16x",datapath.id)


    # @set_ev_cls(ofp_event.EventOFPPortStatsReply,MAIN_DISPATCHER)
    # def _port_stats_reply_handler(self,ev):
    #     body = ev.msg.body
    #     for stat in sorted(body,key = attrgetter("port_no")):
    #         self.logger.info(ev.msg.datapath.id,stat.port_no,stat.rx_packets,stat.rx_bytes,stat.rx_errors,
    #                          stat.tx_packets)
    @set_ev_cls(ofp_event.EventOFPFlowStatsReply,MAIN_DISPATCHER)
    def _flow_stats_reply_handler(self,ev):
        body = ev.msg.body
        datapathID = ev.msg.datapath.id
        # 源地址变化速率
        # 目的地址变化速率
        # 流包数均值
        # 对比流
        # 端口增速
        # 1. 创建文件对象
        f_attack = open('/home/wyn/computernetwork_homwork/attack.csv', 'a', encoding='utf-8')
        # 2. 基于文件对象构建 csv写入对象
        csv_writer_attack = csv.writer(f_attack)


        # 3. 构建列表头
        #csv_writer_normal.writerow(["ip_src", "ip_dst", "APF", "PPF", "in_port"])
        if datapathID==2:
            ipsrc = []
            ipdst = []
            inport = []
            flag=[False,False]

            item=0
            packet_sum=0
            pair=0
            for flow in body:
                if flow.priority == 1:
                    item = item+1
                    packet_sum = packet_sum+flow.packet_count
                    ipsrc.append(str(flow.match['ipv4_src']).split('.')[-1])
                    ipdst.append(str(flow.match['ipv4_dst']).split('.')[-1])
                    inport.append(flow.match['in_port'])
                    if item >= 2 and ipsrc[item-1] == ipdst[item-2] and ipdst[item-1] == ipsrc[item-2] and flag[item-2]==False:
                        pair = pair+1
                        flag.append(True)
                        flag[item-2]=True

                    else:
                        flag.append(False)
            csv_writer_attack.writerow([ipsrc, ipdst, packet_sum/item, 2.0*pair/item, inport])