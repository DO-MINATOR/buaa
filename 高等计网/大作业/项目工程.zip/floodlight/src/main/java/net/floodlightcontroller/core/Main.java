package net.floodlightcontroller.core;

import net.floodlightcontroller.core.internal.CmdLineSettings;
import net.floodlightcontroller.core.module.FloodlightModuleException;
import net.floodlightcontroller.core.module.FloodlightModuleLoader;
import net.floodlightcontroller.core.module.IFloodlightModuleContext;
import net.floodlightcontroller.restserver.IRestApiService;
import org.kohsuke.args4j.CmdLineException;
import org.kohsuke.args4j.CmdLineParser;

/**
 * Host for the Floodlight main method
 *
 * @author alexreimers
 */
public class Main {

    /**
     * Main method to load configuration and modules
     *
     * @param args
     * @throws FloodlightModuleException
     */
    public static void main(String[] args) throws FloodlightModuleException {
        // Setup logger
        System.setProperty("org.restlet.engine.loggerFacadeClass",
                "org.restlet.ext.slf4j.Slf4jLoggerFacade");

        CmdLineSettings settings = new CmdLineSettings();//实例化CmdLineParser类，用于解析用户配置文件，
        CmdLineParser parser = new CmdLineParser(settings);//解析命令行配置的参数
        try {
            parser.parseArgument(args);
        } catch (CmdLineException e) {
            parser.printUsage(System.out);
            System.exit(1);
        }

        // Load modules
        FloodlightModuleLoader fml = new FloodlightModuleLoader();//创建模块加载器
        IFloodlightModuleContext moduleContext = fml.loadModulesFromConfig(settings.getModuleFile());//从配置文件中加载模块，返回加载好模块后的上下文环境
        // Run REST server
        IRestApiService restApi = moduleContext.getServiceImpl(IRestApiService.class);
        restApi.run();//部署ResApi服务

        // Run the main floodlight module
        IFloodlightProviderService controller = moduleContext.getServiceImpl(IFloodlightProviderService.class);//加载模块
        // This call blocks, it has to be the last line in the main
        controller.run();
    }
}
