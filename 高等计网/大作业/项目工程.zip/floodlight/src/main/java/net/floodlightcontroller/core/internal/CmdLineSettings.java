package net.floodlightcontroller.core.internal;

import org.kohsuke.args4j.Option;

/**
 * Expresses the port settings of OpenFlow controller.
 */
public class CmdLineSettings {
    public static final String DEFAULT_CONFIG_FILE = "config/floodlight.properties";
    //默认模块配置文件

    @Option(name="-cf", aliases="--configFile", metaVar="FILE", usage="Floodlight configuration file")
    private String configFile = DEFAULT_CONFIG_FILE;
    
    public String getModuleFile() {
    	return configFile;
    }
}
