package net.floodlightcontroller.routing;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Curl {
    //通过cmd命令向controller发送curl命令，用于下发流表
    public static String execCurl(String[] cmds) {
        ProcessBuilder process = new ProcessBuilder(cmds);//调用windows cmd程序
        Process p;
        try {
            p = process.start();
            BufferedReader reader = new BufferedReader(new InputStreamReader(p.getInputStream()));//cmd读取传入的cmds命令行字符串
            StringBuilder builder = new StringBuilder();
            String line = null;
            while ((line = reader.readLine()) != null) {
                builder.append(line);
                builder.append(System.getProperty("line.separator"));//执行命令
            }
            return builder.toString();//返回执行结果

        } catch (IOException e) {
            System.out.print("error");
            e.printStackTrace();
        }
        return null;
    }
}