#coding=utf-8
import sys
import getopt
import logging
logging.getLogger("scapy.runtime").setLevel(logging.ERROR)
from scapy.all import IP, TCP, sr
from random import randrange

#目标ip地址产生函数，生成范围为10.0.0.start-10.0.0.end
def generateDestinationIP(start, end):
    first = 10
    second = 0
    third = 0

    ip = ".".join([str(first), str(second), str(third), str(randrange(start,end))])
    return ip

def main(argv):
    #从启动命令中获取inter，retry，timeout，fixed参数，用于在向目标服务器发送请求回送报文设置发送间隔、超时重传和等待时间，以及目标ip地址是否固定为10.0.0.64
    try:
        opts, args = getopt.getopt(sys.argv[1:], 'i:r:t:f:', ['inter=','retry=','timeout=','fixed='])
    except getopt.GetoptError:
        sys.exit(-1)

    for opt, arg in opts:
        if opt =='-i':
            inter = float(arg)
        elif opt =='-r':
            retry = int(arg)
        elif opt =='-t':
            timeout = float(arg)
        elif opt =='-f':
            fixed = bool(int(arg))

    if inter == '' or retry == '' or timeout == '' or fixed == '':
        sys.exit(-1)

    num=100
    #循环发送次数

    for i in xrange(num):
        #如果设值fixed=1（固定），则目标ip地址设值为10.0.0.64，否则在10.0.0.2——10.0.0.64范围内随机产生
        if(fixed == True):
            desIp = "10.0.0.64"
        else:
            desIp = generateDestinationIP(2, 65)

        print("get reply from : ip[+"+ desIp +"]")
        a,b = sr(IP(dst = desIp)/TCP(),inter = inter, retry = retry, timeout = timeout)
        #生成请求响应报文，数据包发送间隔inter，无应答时重发次数retry，数据包等待时间timeout

if __name__ == '__main__':
  main(sys.argv)
