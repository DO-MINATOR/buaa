#coding=utf-8
import sys
import time
import getopt
from os import popen
import logging
logging.getLogger("scapy.runtime").setLevel(logging.ERROR)
from scapy.all import sendp, IP, UDP, Ether
from random import randrange
import random

#生成范围为10.0.0.start——10.0.0.end范围内的ip地址
def generateSourceIP(start, end):
    first = 10
    second = 0
    third = 0

    ip = ".".join([str(first), str(second), str(third), str(randrange(start,end))])
    return ip

def generateDestinationIP(start, end):
    first = 10
    second = 0
    third = 0

    ip = ".".join([str(first), str(second), str(third), str(randrange(start,end))])
    return ip

'''
输入：
    源IP，目的IP，攻击类型，攻击次数
输出：
    攻击流字符串
'''
def attack(desIp, srcIp, type, iter):
    flow = ''
    k = 10
    m = k * k
    send_pkt_num = 0
    get_pkt_num = 0
    therd = 50          # 向同一Ip发包数量阈值
    # DDos攻击流A，任意srcIp向固定desIp, 发包速率(30kbps, 70kbps)，收包速率(1kbps, 4kbps)，
    # 向同一ip目的地址发送数据报数量>=50
    if type == 1:
        send_pkt_num = random.randint(30 * k, 70 * k)
        get_pkt_num = random.randint(1 * k, 4 * k)
    # 高速率正常突发大流量N1，任意srcIp向固定desIp，发包速率/收包速率(300mbps, 700mbps)
    elif type == 2:
        send_pkt_num = random.randint(30 * m, 70 * m)
        get_pkt_num = random.randint(30 * m, 70 * m)
    # 正常非对称小流量N2，任意srcIp向多个desIp，发包速率(30kbps, 70kbps)，收包速率(1kbps, 4kbps)，
    # 向同一ip目的地址发送数据报数量<50
    elif type == 3:
        send_pkt_num = random.randint(30 * k, 70 * k)
        get_pkt_num = random.randint(1 * k, 4 * k)
        if iter >= 50:                 # 超过50阈值
            desIp = desIp.split('.')
            desIp[-1] = str(int(desIp[-1]) - int(iter / 50))        # 换一个目的Ip地址发送
            desIp = '.'.join(list(map(str, desIp)))
    # 正常对称小流量N3，任意srcIp向多个desIp，发包速率/收包速率(30kbps, 70kbps)，
    # 向同一ip目的地址发送数据报数量<50
    elif type == 4:
        send_pkt_num = random.randint(30 * k, 70 * k)
        get_pkt_num = random.randint(30 * k, 70 * k)
        if iter >= 50:  # 超过50阈值
            desIp = desIp.split('.')
            desIp[-1] = str(int(desIp[-1]) - int(iter / 50))  # 换一个目的Ip地址发送
            desIp = '.'.join(list(map(str, desIp)))
    flow = desIp + ',' + srcIp + ',' + str(send_pkt_num) + ',' + str(get_pkt_num)
    return flow


def main(conn, argv):
    #获取启动参数，start，end用于控制生成ip地址的范围，fixed设置目标ip地址是否固定
    try:
        opts, args = getopt.getopt(argv[1:7], 's:e:f:c', ['start=','end=','fixed='])
    except getopt.GetoptError:
        sys.exit(-1)

    for opt, arg in opts:
        if opt =='-s':
            start = int(arg)
        elif opt =='-e':
            end = int(arg)
        elif opt =='-f':
            fixed = bool(int(arg))

    if start == '' or end == '' or fixed == '':
        sys.exit(-1)

    #总共4轮攻击，每轮Dos攻击100次
    for i in range (1, 5):
        for j in range(1, 101):
            if(fixed == True):
                desIp = "10.0.0.64"
            else:
                desIp = generateDestinationIP(start, end)
            scrIp = generateSourceIP(start,end)
            packets = Ether() / IP(dst = desIp, src = scrIp) / UDP(dport = 1, sport = 80)
            #如果是链路带宽攻击，则设值目标ip地址随机，如果是对主机计算资源攻击，则设值目标ip地址固定
            print(repr(packets))
            sendp(packets, inter = 0.01)
            # 发送间隔为0.025秒，用于模拟请求泛洪
            flow =  attack(desIp, scrIp, i, j)
            conn.send(flow)
            time.sleep(0.5)
        time.sleep(2)
    conn.send('EOF')
    conn.close()

if __name__=="__main__":
    main(sys.argv)
