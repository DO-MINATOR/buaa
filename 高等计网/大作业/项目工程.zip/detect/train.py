import numpy as np
import pandas as pd
import random
from sklearn.preprocessing import StandardScaler
from sklearn.neural_network import MLPClassifier
from sklearn.metrics import classification_report

df_attack = pd.read_csv("attack.csv")
df_normal = pd.read_csv("normal.csv")
ipsrc = []
ipdst = []
packet = []
pair = []
inport = []
label = []
random_sort = []
rows_attack = df_attack.shape[0]
rows_normal = df_normal.shape[0]
for i in range(1,rows_attack):
    srcold = df_attack.iloc[i-1, 0]
    srcnew = df_attack.iloc[i, 0]
    ipsrc.append(len(srcnew)-len(srcold))
    dstold = df_attack.iloc[i - 1, 1]
    dstnew = df_attack.iloc[i, 1]
    ipdst.append(len(dstnew)-len(dstold))
    packet.append(df_attack.iloc[i, 2])
    pair.append(df_attack.iloc[i, 3])
    portold = df_attack.iloc[i - 1, 4]
    portnew = df_attack.iloc[i, 4]
    inport.append(len(portnew)-len(portold))
    label.append(1)
    r = random.randint(0,1000)
    random_sort.append(r)

for i in range(1,rows_normal):
    srcold = df_normal.iloc[i-1, 0]
    srcnew = df_normal.iloc[i, 0]
    ipsrc.append(len(srcnew)-len(srcold))
    dstold = df_normal.iloc[i - 1, 1]
    dstnew = df_normal.iloc[i, 1]
    ipdst.append(len(dstnew)-len(dstold))
    packet.append(df_normal.iloc[i, 2])
    pair.append(df_normal.iloc[i, 3])
    portold = df_normal.iloc[i - 1, 4]
    portnew = df_normal.iloc[i, 4]
    inport.append(len(portnew)-len(portold))
    label.append(0)
    r = random.randint(0,1000)
    random_sort.append(r)
data={"ipsrc":ipsrc,"ipdst":ipdst,"packet":packet,'pair':pair,'inport':inport,'label':label,'random':random_sort}
df=pd.DataFrame(data)
df.to_csv('test.csv')

dates = pd.read_csv("test.csv")
x_train = dates.iloc[0:600, :5]
y_train = dates.iloc[0:600, 5]
x_test = dates.iloc[600:, :5]
y_test = dates.iloc[600:, 5]
# 神经网络对数据尺度敏感，所以最好在训练前标准化，或者归一化，或者缩放到[-1,1]
# 数据标准化
scaler = StandardScaler()  # 标准化转换
scaler.fit(x_test)  # 训练标准化对象
x_test_Standard = scaler.transform(x_test)  # 转换数据集
scaler.fit(x_train)  # 训练标准化对象
x_train_Standard = scaler.transform(x_train)  # 转换数据集
#
bp = MLPClassifier(hidden_layer_sizes=(100,), activation='relu',
                   solver='lbfgs', alpha=0.0001, batch_size='auto',
                   learning_rate='constant')
bp.fit(x_train_Standard, y_train.astype('int'))
y_predict = bp.predict(x_test_Standard)
print(classification_report(y_predict,y_test))
