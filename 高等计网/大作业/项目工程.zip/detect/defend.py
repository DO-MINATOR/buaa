'''
防御模块，基于双向流量检测。
输入实时流量，分析流量四元组特征，输出检测结果。
'''
import time

# 分类模块
def GHSOM(list):
    # 速率
    pkt_1 = [i for i in range(10,40)]
    pkt_2 = [i for i in range(300,700)]
    pkt_3 = [i for i in range(3000,7000)]
    desIp_list = [item[0] for item in list]         # 取出desIp
    desIp_host_list = [int(item.split('.')[-1]) for item in desIp_list]      # 取出desIp最后一位
    desIp_host_set = set(desIp_host_list)
    attack_count = [0,0,0,0]           # 四种攻击
    attack_type = ['DDos攻击A', '高速率正常突发大流量N1', '正常非对称小流量N2', '正常对称小流量N3']

    for flow in list:
        send_pkt = int(flow[2])
        get_pkt = int(flow[3])
        # 固定desIp
        if len(desIp_host_set) == 1:
            if send_pkt in pkt_3 and get_pkt in pkt_3:
                attack_count[1] += 1
            elif send_pkt in pkt_2:
                if get_pkt in pkt_1:
                    if len(desIp_host_list) >= 50:
                        attack_count[0] += 1
                    else:
                        attack_count[2] += 1
                else:
                    attack_count[3] += 1
        else:       # 多个desIp
            if send_pkt in pkt_2 and get_pkt in pkt_1:
                attack_count[2] += 1
            else:
                attack_count[3] += 1
    return attack_type[attack_count.index(max(attack_count))]

def main(conn):
    flow_list = []
    while conn.recv() != 'EOF':
        flow = str(conn.recv())
        flow_list.append(flow.split(','))
        print('#' + str(len(flow_list)) + ':' + flow)  # 生成多种类型的攻击流量
        if len(flow_list) % 10 == 0:             # 每检测到10条数据包分析一次
            print('###### 当前流量检测结果： ' + GHSOM(flow_list) + ' ######')
        if len(flow_list) % 100 == 0:
            flow_list = []
    conn.close()

if __name__ == '__main__':
    main()