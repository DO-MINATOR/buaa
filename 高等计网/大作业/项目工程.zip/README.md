### 项目说明

本项目采用Windows+Linux双系统联调开发，Windows上针对FloodLight开源项目进行二次开发，实现本实验要求的packet-in协调转发模块，单点攻击流量检测模块，以及流表的下发，进而实现针对在虚拟组网环境中的DDoS攻击的防御。在Linux环境下，通过Mininet实现组网环境搭建，配合sFlow以实现对组网环境流量的监控，编写python脚本，实现packet-in链路攻击和单点攻击。

### 项目开发和运行环境

| 系统环境                  | 开发环境     | 版本号                 |
| :------------------------ | ------------ | ---------------------- |
| Windos10 64位 家庭版 1909 | Java开发环境 | Jdk 1.8.0_271          |
|                           | 集成开发环境 | IntelliJ IDEA 2020.2.2 |
|                           | 虚拟机       | Vmware Pro 15.5.6      |
|                           | 网络控制器   | Floodlight v0.9 src    |
| Ubuntu 18.04 LTS 64位     | Java环境     | Jdk 1.8.0_272          |
|                           | Python环境   | Python 2.7.17          |
|                           | 组网软件     | mininet 2.2-2          |
|                           | 流量监控     | sFlow 3.0-1529         |

### 工程文件说明

#### packet-generation\

- attackPk.py为攻击流量生成模块(packet-in链路攻击)，通过在启动命令后跟不同参数可实现packet-in链路带宽攻击包的源ip地址和目标ip地址的随机范围，发送间隔，重传等待时间等，详细启动命令见下一节
- attackSt.py为攻击流量生成模块(单目标攻击)，该攻击模块一共会进行4轮攻击，分别会产生Ddos攻击，高速率正常突发大流量，正常非对称小流量，正常对称小流量4种攻击。


- echo-reply.py为合法流量生成模块，用于测验攻击模块的影响效果，以及FloodLight中防御模块的有效性，同样通过不同启动参数可实现链路带宽攻击的检测和单点攻击的检测。

#### detect\

- defend.py通过GHSOM算法，捕获并分析得到的流量四元组信息，实现检测分类。
- train.py通过收集来的正常流量信息和攻击流量信息，训练神经网络，实现流量类型预测。

#### floodlight\target\

- floodlight.jar为对floodlight进行二次开发后生成的jar包，可直接在Windows或Linux环境下进行部署。

#### floodlight\src\main\java\net\floodlightcontroller\

- core\Main.javaFloodLight的启动入口文件，负责用户配置的导入，模块的加载等
- routing\ForwardingBase.java该模块是所有与交换机数据转发相关的基类，通过改造receive函数和创建运行时线程来计算控制器的负载程度，并切换状态，高负载时下发转发流表，以实现packet-in报文的协调转发。
- routing\Curl.java创建的cmd调用工具类，用于实现流表的下发功能。
- forwarding\Forwarding.java在processPacketInMessage函数中调用线程休眠模拟控制器对packet-in报文的处理，以使得packet-in队列较容易被阻塞。

#### floodlight\src\main\python\get_flow.py

- 该模块为自定义的FloodLight模块，通过修改`floodlight\src\main\resources\`下的floodlightdefault.properties文件，新增该模块，即可在FloodLight启动时加载该模块，该模块主要实现将数据流收集并写入到csv文件，供神经网络模型训练。

#### command.txt

- 该文件为常用启动命令，包括floodlight启动，mininet组网命令，sflow-agent启动等。

### 项目启动说明

1. 配置Linux与Windows的网络联通接口，在Vmware上通过配置NAT地址映射，虚拟机网关设置为192.168.137.2，子网掩码为255.255.255.0，本机ip为192.168.137.181。
2. Windows上在floodlight目录下，启动控制器进程，命令为`java -jar target/floodlight.jar`，默认北向端口8080，南向端口6633，可在`src\main\resources\floodlightdefault.properties`进行更改。
3. FloodLight启动后，浏览器输入`127.0.0.1:8080/ui/index.html`打开控制器前端界面。
4. 在Linux环境下，通过Mininet搭建组网，若没有mininet环境，则使用`sudo apt-get install mn`命令安装Mininet，之后通过命令行方式搭建虚拟网络环境`sudo mn --switch ovsk --topo tree,depth=2,fanout=8 --controller=remote,ip=10.4.9.251,port=6633`，各参数意义如下：
   - sudo：由于虚拟组网环境需要调用到内核网卡接口，因此需要管理员权限运行。
   - --switch：指定网络中交换机的类型，由于该实验交换机需要与控制器进行交互，因此需选用能够支持OpenFlow协议的交换机，ovsk中的ovs即代表Open vSwitch。
   - --topo：网络拓扑结构类型，常见的有single（单点）、linear（总线）、tree（树形）结构，根据选择的类型不同，需要指定具体的细分参数，如树形结构中需指明树深度，节点度数。
   - --controller：指定控制器来源，需指明ip地址和端口号。
5. 执行pingall进行网络联通性测试，另外，可通过`xterm h1`单独为每个主机节点启动命令行窗口，例如，在h1上执行`ping 10.0.0.32`实现h1主机pingh32主机
6. 启用sflow，对流量进行监管，如果没有该程序，则先通过`wget https://inmon.com/products/sFlow-RT/sflow-rt.tar.gz`下载sflow压缩包，在程序根部目录下，通过`./start.sh`启动监控软件。
7. 在虚拟网络节点上配置sflow-agent，配置命令为：`sudo ovs-vsctl -- --id=@sflow create sflow agent=eth0 target=\"127.0.0.1:6343\" sampling=10 polling=20 -- -- set bridge s1 sflow=@sflow`，各参数意义如下：
   - agent：指定采样的网卡，由于虚拟组网环境中，所有的流量都会经过虚拟机的主网卡，因此网卡为eth0。
   - target：sFlow服务端地址，默认端口号为6343。
   - sampling：采样率，即每隔N个Packet采样一次。
   - polling：轮询时间，即每隔N秒轮询一次。
   - bridge：被监控的网络设备，这里以h1所在的交换机s1为例，待会儿以h1主机进行ping报文测试，查看流经s1的流量。需说明的是，如果要针对全网环境测试的话，该命令需要多次配置，以覆盖所有交换机/路由器。
8. 在浏览器地址栏输入`127.0.0.1:8008`可查看流量信息。
9. 在h1节点上启动请求回送程序(echo-reply.py)，在mininet窗口下通过xterm h1启动h1的命令窗口，通过`python echo-reply.py -i 0.5 -r 3 -t 0.5 -f 0`启动该程序，-i：发送间隔，-r：若超时后则重传的报文数量，-t：等待响应报文的时长，-f：设置目标主机ip地址是否固定（packet-in链路攻击场景不固定，单点攻击场景固定）
10. 在h2节点上启动packet-in链路攻击程序，命令为`python attackPk.py -s 2 -e 65 -f 0`，-s和-e用于选取源ip地址范围，-f设置目标ip地址是否固定（该场景下不固定）。由于FloodLight中配置了packet-in转发模块，因此能够抵御该种攻击，查看h1节点的请求回送程序，响应正常。
11. 在h2节点上启动单点攻击程序，命令为`python attackSt.py -s 2 -e 65 -f 1`，设置目标ip地址固定。同样由于FloodLight配置了针对单点攻击的防御模块，因此h1节点的请求回送程序仍能正常工作。